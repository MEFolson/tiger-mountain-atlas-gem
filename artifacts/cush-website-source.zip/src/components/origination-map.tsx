import { useEffect, useId, useMemo, useState } from "react";
import { cn } from "@/lib/utils";

type Pt = { lon: number; lat: number };
type XY = { x: number; y: number };

const W = 1100;
const H = 780;
const CX = 550;
const CY = 390;
const R = 236;
const ACCRA_PT: Pt = { lon: -0.19, lat: 5.6 };

function rad(d: number) {
  return (d * Math.PI) / 180;
}

function project(lon: number, lat: number) {
  const φ = rad(lat);
  const λ = rad(lon);
  const φ0 = rad(ACCRA_PT.lat);
  const λ0 = rad(ACCRA_PT.lon);
  const dλ = λ - λ0;
  const cosc = Math.min(
    1,
    Math.max(
      -1,
      Math.sin(φ0) * Math.sin(φ) + Math.cos(φ0) * Math.cos(φ) * Math.cos(dλ),
    ),
  );
  const c = Math.acos(cosc);
  const k = Math.abs(c) < 1e-8 ? 1 : c / Math.sin(c);
  const x = k * Math.cos(φ) * Math.sin(dλ);
  const y =
    k *
    (Math.cos(φ0) * Math.sin(φ) - Math.sin(φ0) * Math.cos(φ) * Math.cos(dλ));
  return { x, y, c };
}

const AFRICA: Pt[] = [
  { lon: -5.6, lat: 35.8 },
  { lon: -2.2, lat: 35.2 },
  { lon: 1.2, lat: 36.5 },
  { lon: 6.2, lat: 37.0 },
  { lon: 10.3, lat: 36.9 },
  { lon: 11.0, lat: 33.2 },
  { lon: 15.5, lat: 32.3 },
  { lon: 20.0, lat: 32.3 },
  { lon: 25.0, lat: 31.8 },
  { lon: 29.9, lat: 31.4 },
  { lon: 32.6, lat: 31.2 },
  { lon: 34.0, lat: 27.6 },
  { lon: 36.6, lat: 23.2 },
  { lon: 38.6, lat: 18.0 },
  { lon: 42.4, lat: 15.2 },
  { lon: 43.3, lat: 12.6 },
  { lon: 48.2, lat: 11.3 },
  { lon: 51.2, lat: 11.8 },
  { lon: 50.7, lat: 8.2 },
  { lon: 47.4, lat: 4.4 },
  { lon: 43.6, lat: 1.2 },
  { lon: 41.8, lat: -1.6 },
  { lon: 40.9, lat: -2.3 },
  { lon: 40.4, lat: -5.0 },
  { lon: 39.4, lat: -8.5 },
  { lon: 40.4, lat: -14.4 },
  { lon: 36.8, lat: -17.6 },
  { lon: 35.0, lat: -22.2 },
  { lon: 32.6, lat: -26.0 },
  { lon: 29.2, lat: -31.6 },
  { lon: 26.4, lat: -33.8 },
  { lon: 22.2, lat: -34.3 },
  { lon: 18.4, lat: -34.8 },
  { lon: 18.3, lat: -31.6 },
  { lon: 16.4, lat: -28.6 },
  { lon: 14.5, lat: -22.8 },
  { lon: 12.4, lat: -17.0 },
  { lon: 11.8, lat: -15.0 },
  { lon: 13.5, lat: -9.8 },
  { lon: 12.3, lat: -6.2 },
  { lon: 9.8, lat: 0.4 },
  { lon: 8.8, lat: 4.6 },
  { lon: 6.6, lat: 4.3 },
  { lon: 3.5, lat: 6.4 },
  { lon: 1.2, lat: 6.2 },
  { lon: -0.2, lat: 5.5 },
  { lon: -3.1, lat: 4.9 },
  { lon: -7.6, lat: 4.4 },
  { lon: -10.0, lat: 6.1 },
  { lon: -13.7, lat: 9.4 },
  { lon: -16.6, lat: 12.4 },
  { lon: -17.5, lat: 14.7 },
  { lon: -16.4, lat: 19.8 },
  { lon: -16.0, lat: 23.6 },
  { lon: -14.5, lat: 26.6 },
  { lon: -11.8, lat: 28.0 },
  { lon: -9.8, lat: 31.4 },
  { lon: -8.0, lat: 33.5 },
  { lon: -6.3, lat: 34.9 },
];

const MADAGASCAR: Pt[] = [
  { lon: 49.2, lat: -12.0 },
  { lon: 50.4, lat: -15.4 },
  { lon: 47.7, lat: -24.8 },
  { lon: 45.2, lat: -25.6 },
  { lon: 43.4, lat: -22.0 },
  { lon: 44.0, lat: -17.4 },
  { lon: 47.2, lat: -13.2 },
];

const LANDS: Pt[][] = [
  [
    { lon: -166, lat: 66 },
    { lon: -141, lat: 60 },
    { lon: -130, lat: 55 },
    { lon: -124, lat: 48 },
    { lon: -124.4, lat: 40.4 },
    { lon: -117.2, lat: 32.6 },
    { lon: -110.2, lat: 24.2 },
    { lon: -97.4, lat: 25.8 },
    { lon: -90.2, lat: 29.0 },
    { lon: -84.0, lat: 22.2 },
    { lon: -80.8, lat: 25.2 },
    { lon: -81.4, lat: 31.2 },
    { lon: -76.0, lat: 35.4 },
    { lon: -74.0, lat: 40.4 },
    { lon: -69.8, lat: 41.8 },
    { lon: -66.0, lat: 44.8 },
    { lon: -60.0, lat: 47.0 },
    { lon: -56.0, lat: 51.2 },
    { lon: -61.8, lat: 58.4 },
    { lon: -78.0, lat: 62.4 },
    { lon: -95.0, lat: 68.2 },
    { lon: -120.0, lat: 69.4 },
    { lon: -141.0, lat: 70.0 },
    { lon: -165.0, lat: 68.0 },
  ],
  [
    { lon: -80.8, lat: 8.4 },
    { lon: -70.2, lat: 11.8 },
    { lon: -60.2, lat: 8.4 },
    { lon: -51.2, lat: 4.2 },
    { lon: -34.8, lat: -5.2 },
    { lon: -38.4, lat: -15.2 },
    { lon: -40.6, lat: -22.2 },
    { lon: -48.0, lat: -28.4 },
    { lon: -53.6, lat: -34.6 },
    { lon: -67.6, lat: -55.0 },
    { lon: -71.4, lat: -51.2 },
    { lon: -73.4, lat: -42.0 },
    { lon: -76.2, lat: -14.6 },
    { lon: -81.2, lat: -4.8 },
  ],
  [
    { lon: -9.4, lat: 43.0 },
    { lon: -8.8, lat: 37.0 },
    { lon: -5.6, lat: 36.0 },
    { lon: -1.2, lat: 43.4 },
    { lon: 3.2, lat: 42.4 },
    { lon: 9.2, lat: 44.2 },
    { lon: 12.4, lat: 41.6 },
    { lon: 18.4, lat: 40.4 },
    { lon: 28.2, lat: 41.0 },
    { lon: 29.2, lat: 45.2 },
    { lon: 23.8, lat: 45.0 },
    { lon: 13.6, lat: 46.2 },
    { lon: 12.2, lat: 54.2 },
    { lon: 8.2, lat: 55.4 },
    { lon: 4.2, lat: 52.2 },
    { lon: -1.6, lat: 50.6 },
    { lon: -5.2, lat: 48.4 },
  ],
  [
    { lon: -10.4, lat: 51.4 },
    { lon: -6.2, lat: 52.0 },
    { lon: -5.4, lat: 50.0 },
    { lon: -1.8, lat: 50.6 },
    { lon: 1.6, lat: 52.6 },
    { lon: -1.8, lat: 55.8 },
    { lon: -4.8, lat: 55.8 },
    { lon: -6.0, lat: 58.6 },
    { lon: -3.0, lat: 58.6 },
    { lon: -5.0, lat: 56.2 },
    { lon: -7.4, lat: 57.6 },
    { lon: -7.6, lat: 54.2 },
    { lon: -10.0, lat: 54.4 },
  ],
  [
    { lon: 26.4, lat: 40.8 },
    { lon: 36.2, lat: 36.2 },
    { lon: 44.2, lat: 40.0 },
    { lon: 48.4, lat: 30.0 },
    { lon: 56.2, lat: 27.0 },
    { lon: 60.2, lat: 25.2 },
    { lon: 69.4, lat: 22.6 },
    { lon: 77.4, lat: 8.2 },
    { lon: 80.2, lat: 6.0 },
    { lon: 81.4, lat: 15.8 },
    { lon: 94.2, lat: 16.0 },
    { lon: 98.2, lat: 9.2 },
    { lon: 104.2, lat: 1.4 },
    { lon: 109.2, lat: 1.6 },
    { lon: 109.0, lat: 13.8 },
    { lon: 119.2, lat: 24.2 },
    { lon: 122.0, lat: 31.2 },
    { lon: 129.4, lat: 35.2 },
    { lon: 140.8, lat: 37.2 },
    { lon: 141.8, lat: 45.4 },
    { lon: 130.0, lat: 50.2 },
    { lon: 110.0, lat: 55.0 },
    { lon: 90.0, lat: 47.2 },
    { lon: 74.6, lat: 40.2 },
    { lon: 66.8, lat: 45.2 },
    { lon: 48.4, lat: 41.6 },
    { lon: 40.0, lat: 43.8 },
  ],
  [
    { lon: 114.2, lat: -22.0 },
    { lon: 126.2, lat: -14.0 },
    { lon: 136.4, lat: -12.2 },
    { lon: 145.6, lat: -15.0 },
    { lon: 153.2, lat: -25.2 },
    { lon: 150.4, lat: -37.2 },
    { lon: 139.6, lat: -38.2 },
    { lon: 115.4, lat: -34.8 },
  ],
];

const ORIGINS = [
  { id: "nyc", name: "New York", pt: { lon: -74.0, lat: 40.7 }, side: "w" },
  { id: "tor", name: "Toronto", pt: { lon: -79.4, lat: 43.7 }, side: "n" },
  { id: "sao", name: "São Paulo", pt: { lon: -46.6, lat: -23.6 }, side: "s" },
  { id: "lon", name: "London", pt: { lon: -0.12, lat: 51.5 }, side: "n" },
  { id: "par", name: "Paris", pt: { lon: 2.35, lat: 48.9 }, side: "e" },
  { id: "dxb", name: "Dubai", pt: { lon: 55.3, lat: 25.2 }, side: "n" },
  { id: "mum", name: "Mumbai", pt: { lon: 72.9, lat: 19.1 }, side: "e" },
  { id: "sin", name: "Singapore", pt: { lon: 103.8, lat: 1.35 }, side: "e" },
  { id: "syd", name: "Sydney", pt: { lon: 151.2, lat: -33.9 }, side: "s" },
] as const;

const AFRICA_CITIES = [
  { id: "accra", name: "Accra", pt: ACCRA_PT, hub: true },
  { id: "dakar", name: "Dakar", pt: { lon: -17.5, lat: 14.7 }, hub: false },
  { id: "nbo", name: "Nairobi", pt: { lon: 36.82, lat: -1.29 }, hub: false },
  { id: "jnb", name: "Johannesburg", pt: { lon: 28.05, lat: -26.2 }, hub: false },
] as const;

function makeXy(scale: number) {
  return (pt: Pt): XY => {
    const p = project(pt.lon, pt.lat);
    return {
      x: Math.round((CX + p.x * scale) * 10) / 10,
      y: Math.round((CY - p.y * scale) * 10) / 10,
    };
  };
}

function smoothPath(pts: XY[]) {
  const n = pts.length;
  if (n < 3) return "";
  const get = (i: number) => pts[(i + n) % n];
  let d = `M${get(0).x.toFixed(1)} ${get(0).y.toFixed(1)}`;
  for (let i = 0; i < n; i++) {
    const p0 = get(i - 1);
    const p1 = get(i);
    const p2 = get(i + 1);
    const p3 = get(i + 2);
    d += `C${(p1.x + (p2.x - p0.x) / 6).toFixed(1)} ${(p1.y + (p2.y - p0.y) / 6).toFixed(1)} ${(p2.x - (p3.x - p1.x) / 6).toFixed(1)} ${(p2.y - (p3.y - p1.y) / 6).toFixed(1)} ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`;
  }
  return `${d}Z`;
}

const labelClass = {
  n: "-translate-x-1/2 -translate-y-[calc(100%+10px)]",
  s: "-translate-x-1/2 translate-y-[10px]",
  e: "translate-x-[10px] -translate-y-1/2",
  w: "-translate-x-[calc(100%+10px)] -translate-y-1/2",
} as const;

export function OriginationMap({ className }: { className?: string }) {
  const uid = useId().replace(/:/g, "");
  const [active, setActive] = useState(0);
  const [hover, setHover] = useState<string | null>(null);

  useEffect(() => {
    if (hover) return;
    const id = window.setInterval(
      () => setActive((n) => (n + 1) % ORIGINS.length),
      2800,
    );
    return () => window.clearInterval(id);
  }, [hover]);

  const current = hover
    ? (ORIGINS.find((o) => o.id === hover) ?? ORIGINS[active])
    : ORIGINS[active];

  const scale = useMemo(() => {
    const maxC = Math.max(
      ...ORIGINS.map((o) => project(o.pt.lon, o.pt.lat).c),
      ...AFRICA.map((p) => project(p.lon, p.lat).c),
      0.9,
    );
    return (R * 0.84) / maxC;
  }, []);

  const xy = useMemo(() => makeXy(scale), [scale]);
  const accra = xy(ACCRA_PT);

  const landPaths = useMemo(
    () => LANDS.map((land) => smoothPath(land.map(xy))),
    [xy],
  );
  const africaPath = useMemo(() => smoothPath(AFRICA.map(xy)), [xy]);
  const madagascarPath = useMemo(() => smoothPath(MADAGASCAR.map(xy)), [xy]);

  const origins = useMemo(
    () => ORIGINS.map((o) => ({ ...o, p: xy(o.pt) })),
    [xy],
  );
  const cities = useMemo(
    () => AFRICA_CITIES.map((c) => ({ ...c, p: xy(c.pt) })),
    [xy],
  );

  const rings = [0.28, 0.52, 0.76, 1].map((t) => R * t);

  return (
    <figure
      className={cn(
        "overflow-hidden rounded-xl bg-[#f3efe6] shadow-[0_0_0_1px_rgb(23_20_17_/_0.08),0_24px_48px_-28px_rgb(23_20_17_/_0.35)]",
        className,
      )}
    >
      <div className="grain relative">
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="h-auto w-full"
        role="img"
        aria-label="Money originating in cities around the world and terminating in Africa"
      >
        <defs>
          <radialGradient id={`${uid}-disk`} cx="42%" cy="36%" r="68%">
            <stop offset="0%" stopColor="#fffaf2" />
            <stop offset="52%" stopColor="#f4efe4" />
            <stop offset="100%" stopColor="#e4d9c6" />
          </radialGradient>
          <radialGradient id={`${uid}-africa`} cx="48%" cy="42%" r="62%">
            <stop offset="0%" stopColor="#f08c3a" stopOpacity="0.55" />
            <stop offset="55%" stopColor="#e85d04" stopOpacity="0.38" />
            <stop offset="100%" stopColor="#c24c03" stopOpacity="0.22" />
          </radialGradient>
          <radialGradient id={`${uid}-sheen`} cx="36%" cy="30%" r="72%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.38" />
            <stop offset="28%" stopColor="#ffffff" stopOpacity="0.08" />
            <stop offset="70%" stopColor="#171411" stopOpacity="0" />
            <stop offset="100%" stopColor="#171411" stopOpacity="0.1" />
          </radialGradient>
          <filter id={`${uid}-glow`} x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="3.2" />
          </filter>
          <clipPath id={`${uid}-clip`}>
            <circle cx={CX} cy={CY} r={R} />
          </clipPath>
        </defs>

        <circle
          cx={CX}
          cy={CY}
          r={R + 18}
          fill="none"
          stroke="#171411"
          strokeOpacity="0.06"
          strokeWidth="1"
        />
        <circle cx={CX} cy={CY} r={R} fill={`url(#${uid}-disk)`} />
        <circle
          cx={CX}
          cy={CY}
          r={R}
          fill="none"
          stroke="#171411"
          strokeOpacity="0.14"
          strokeWidth="1.15"
        />

        <g clipPath={`url(#${uid}-clip)`}>
          {rings.map((r) => (
            <circle
              key={r}
              cx={CX}
              cy={CY}
              r={r}
              fill="none"
              stroke="#171411"
              strokeOpacity="0.07"
              strokeWidth="0.8"
            />
          ))}

          {landPaths.map((d, i) => (
            <path key={i} d={d} fill="#171411" fillOpacity="0.07" />
          ))}

          <path d={africaPath} fill={`url(#${uid}-africa)`} />
          <path
            d={africaPath}
            fill="none"
            stroke="#e85d04"
            strokeOpacity="0.85"
            strokeWidth="1.35"
          />
          <path d={madagascarPath} fill="#e85d04" fillOpacity="0.32" />

          {cities
            .filter((c) => !c.hub)
            .map((c) => (
              <line
                key={`spoke-${c.id}`}
                x1={accra.x}
                y1={accra.y}
                x2={c.p.x}
                y2={c.p.y}
                stroke="#e85d04"
                strokeOpacity="0.28"
                strokeWidth="1"
              />
            ))}

          {origins.map((o) => {
            const on = o.id === current.id;
            return (
              <g key={o.id}>
                {on ? (
                  <line
                    x1={o.p.x}
                    y1={o.p.y}
                    x2={accra.x}
                    y2={accra.y}
                    stroke="#e85d04"
                    strokeWidth="10"
                    strokeOpacity="0.16"
                    strokeLinecap="round"
                    filter={`url(#${uid}-glow)`}
                  />
                ) : null}
                <line
                  x1={o.p.x}
                  y1={o.p.y}
                  x2={accra.x}
                  y2={accra.y}
                  stroke="#e85d04"
                  strokeWidth={on ? 1.7 : 1}
                  strokeOpacity={on ? 0.95 : 0.22}
                  strokeLinecap="round"
                />
              </g>
            );
          })}

          <circle cx={CX} cy={CY} r={R} fill={`url(#${uid}-sheen)`} />
        </g>

        {origins.map((o) => {
          const on = o.id === current.id;
          return (
            <g
              key={`dot-${o.id}`}
              onMouseEnter={() => setHover(o.id)}
              onMouseLeave={() => setHover(null)}
              className="cursor-pointer"
            >
              <circle cx={o.p.x} cy={o.p.y} r="14" fill="transparent" />
              <circle
                cx={o.p.x}
                cy={o.p.y}
                r={on ? 4.2 : 2.8}
                fill={on ? "#e85d04" : "#171411"}
                fillOpacity={on ? 1 : 0.55}
              />
              {on ? (
                <circle
                  cx={o.p.x}
                  cy={o.p.y}
                  r="8"
                  fill="none"
                  stroke="#e85d04"
                  strokeOpacity="0.45"
                  strokeWidth="1"
                />
              ) : null}
            </g>
          );
        })}

        {cities
          .filter((c) => !c.hub)
          .map((c) => (
            <circle
              key={c.id}
              cx={c.p.x}
              cy={c.p.y}
              r="2.4"
              fill="#e85d04"
              fillOpacity="0.9"
            />
          ))}

        <circle cx={accra.x} cy={accra.y} r="22" fill="#e85d04" fillOpacity="0.1" />
        <circle cx={accra.x} cy={accra.y} r="7" fill="#e85d04" fillOpacity="0.2" />
        <circle cx={accra.x} cy={accra.y} r="4.4" fill="#e85d04" />
        <circle cx={accra.x} cy={accra.y} r="1.8" fill="#fffaf2" />

        {origins.map((o) =>
          o.id === current.id ? (
            <circle key={`p-${o.id}`} r="3.1" fill="#fffaf2" stroke="#e85d04" strokeWidth="1.3">
              <animateMotion
                dur="2.6s"
                repeatCount="indefinite"
                rotate="auto"
                keyTimes="0;1"
                calcMode="spline"
                keySplines="0.22 1 0.36 1"
              >
                <mpath href={`#${uid}-live`} />
              </animateMotion>
            </circle>
          ) : null,
        )}
        <path
          id={`${uid}-live`}
          d={`M${origins.find((o) => o.id === current.id)?.p.x} ${origins.find((o) => o.id === current.id)?.p.y} L${accra.x} ${accra.y}`}
          fill="none"
        />
      </svg>

      {origins.map((o) => {
        const on = o.id === current.id;
        return (
          <button
            key={`lbl-${o.id}`}
            type="button"
            onMouseEnter={() => setHover(o.id)}
            onMouseLeave={() => setHover(null)}
            onFocus={() => setHover(o.id)}
            onBlur={() => setHover(null)}
            className={cn(
              "absolute hidden rounded-full px-2.5 py-0.5 text-[11px] tracking-[0.04em] transition-colors md:block",
              labelClass[o.side],
              on
                ? "bg-champagne text-bone shadow-[0_6px_18px_-8px_rgb(232_93_4_/_0.8)]"
                : "bg-[#fffaf2]/90 text-ink shadow-[0_0_0_1px_rgb(23_20_17_/_0.08)] backdrop-blur-sm hover:text-champagne",
            )}
            style={{ left: `${(o.p.x / W) * 100}%`, top: `${(o.p.y / H) * 100}%` }}
          >
            {o.name}
          </button>
        );
      })}

      <div
        className="pointer-events-none absolute hidden font-display text-[13px] text-champagne italic md:block"
        style={{
          left: `${(accra.x / W) * 100}%`,
          top: `${(accra.y / H) * 100}%`,
          transform: "translate(14px, -8px)",
        }}
      >
        Accra
      </div>
      </div>

      <figcaption className="relative flex flex-col gap-1 border-t border-line bg-[#fffaf2]/70 px-5 py-4 backdrop-blur-sm sm:flex-row sm:items-center sm:justify-between">
        <p className="font-mono text-[11px] tracking-[0.16em] text-champagne uppercase">
          {current.name} → Accra → Africa
        </p>
        <p className="text-xs text-stone">
          Origination worldwide. Termination on African rails.
        </p>
      </figcaption>
    </figure>
  );
}
