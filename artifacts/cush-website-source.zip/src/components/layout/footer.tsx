import { Link } from "@tanstack/react-router";
import { brand, nav } from "@/lib/site-data";

export function SiteFooter() {
  return (
    <footer className="border-t border-line bg-surface">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-12 md:px-8">
        <div className="md:col-span-5">
          <img
            src="/images/logo-nav.png"
            alt="Cush Payments"
            className="h-10 w-auto outline-none"
          />
          <p className="mt-4 max-w-sm text-sm text-stone">
            {brand.tagline} {brand.promise}
          </p>
        </div>
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-3 md:col-span-7">
          <div>
            <p className="text-xs tracking-[0.16em] text-ash uppercase">
              Products
            </p>
            <ul className="mt-3 space-y-2 text-sm">
              {nav.map((item) => (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className="text-stone transition-colors hover:text-ink"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-xs tracking-[0.16em] text-ash uppercase">
              Write
            </p>
            <ul className="mt-3 space-y-2 text-sm">
              <li>
                <a
                  className="break-all text-stone hover:text-ink"
                  href={`mailto:${brand.email}`}
                >
                  {brand.email}
                </a>
              </li>
            </ul>
          </div>
          <div>
            <p className="text-xs tracking-[0.16em] text-ash uppercase">
              Status
            </p>
            <p className="mt-3 text-sm text-stone">
              Private beta. UK → Ghana opens first. Designed for FCA and Bank
              of Ghana pathways.
            </p>
          </div>
        </div>
      </div>
      <div className="mx-auto flex max-w-6xl flex-col gap-2 border-t border-line px-5 py-6 text-xs text-ash md:flex-row md:items-center md:justify-between md:px-8">
        <p>© {new Date().getFullYear()} {brand.legal}. All rights reserved.</p>
        <p>Illustrative rates. Not an offer of regulated services.</p>
      </div>
    </footer>
  );
}
