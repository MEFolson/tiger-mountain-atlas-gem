import type { ReactNode } from "react";
import { SiteNav } from "@/components/layout/nav";
import { SiteFooter } from "@/components/layout/footer";
import { WaitlistDialog } from "@/components/waitlist-dialog";

export function SiteShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-svh bg-paper text-ink">
      <SiteNav />
      {children}
      <SiteFooter />
      <WaitlistDialog />
    </div>
  );
}
