import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { nav } from "@/lib/site-data";
import { cn } from "@/lib/utils";
import { useWaitlist } from "@/lib/waitlist-store";

export function SiteNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const openWaitlist = useWaitlist((s) => s.openWith);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-40 bg-paper/95 transition-[box-shadow] duration-200",
        scrolled || open ? "shadow-[0_1px_0_rgb(23_20_17_/_0.08)]" : "",
      )}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 md:h-[4.5rem] md:px-8">
        <Link to="/" aria-label="Cush Payments home" className="flex items-center">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {nav.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "text-sm transition-colors duration-150",
                pathname === item.to
                  ? "text-ink"
                  : "text-stone hover:text-ink",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden md:block">
          <Button size="sm" onClick={() => openWaitlist("sender")}>
            Join the beta
          </Button>
        </div>

        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-full text-ink md:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      {open ? (
        <div className="border-t border-line bg-paper px-5 py-4 md:hidden">
          <nav className="flex flex-col">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="flex h-12 items-center text-base text-ink"
              >
                {item.label}
              </Link>
            ))}
            <Button
              className="mt-3 w-full"
              onClick={() => openWaitlist("sender")}
            >
              Join the beta
            </Button>
          </nav>
        </div>
      ) : null}
    </header>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <img
        src="/images/logo-mark.png"
        alt=""
        className="h-9 w-auto"
      />
    );
  }
  return (
    <>
      <img
        src="/images/logo-mark.png"
        alt=""
        className="h-9 w-auto outline-none md:hidden"
      />
      <img
        src="/images/logo-nav.png"
        alt="Cush Payments"
        className="hidden h-10 w-auto outline-none md:block"
      />
    </>
  );
}
