import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { OriginationMap } from "@/components/origination-map";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { brand, leadership } from "@/lib/site-data";
import { useWaitlist } from "@/lib/waitlist-store";

export const Route = createFileRoute("/company")({
  component: CompanyPage,
  head: () => ({
    meta: [
      { title: "Company — Cush" },
      {
        name: "description",
        content:
          "Cush is the house of African money. Founded by Matthew Ekow Folson and Jose Luis Caldeira. Payments for the diaspora, core for institutions.",
      },
    ],
  }),
});

function CompanyPage() {
  const openWaitlist = useWaitlist((s) => s.openWith);

  return (
    <main>
      <section className="relative overflow-hidden pt-[4.5rem]">
        <img
          src="/images/accra-coast.jpg"
          alt="Accra coastline at dusk"
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-ink/60" />
        <div className="relative mx-auto max-w-6xl px-5 py-28 md:px-8">
          <Badge>Company</Badge>
          <h1 className="mt-4 max-w-3xl font-display text-[clamp(2.15rem,3.4vw+1.05rem,4.5rem)] text-bone">
            Named for a kingdom. Built as a house.
          </h1>
          <p className="mt-5 max-w-xl text-base text-bone-2">
            Cush was an African civilisation that minted, traded, and settled
            on its own terms. Cush is a payments and core-banking house for
            the same idea, now.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 md:px-8">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-5">
            <p className="text-xs tracking-[0.18em] text-champagne uppercase">
              The argument
            </p>
            <h2 className="mt-3 font-display text-4xl text-ink">
              Africa should not rent its rails.
            </h2>
          </div>
          <div className="space-y-5 text-base text-stone md:col-span-7">
            <p>
              For thirty years the continent’s money has travelled on other
              people’s pipes — correspondent banks, card schemes, cores
              designed for London and Frankfurt and bolted onto Accra as an
              afterthought. The fees are the symptom. The architecture is the
              disease.
            </p>
            <p>
              Cush starts the other way. An immutable ledger. Agentic
              orchestration. PAPSS, GHIPSS, and mobile money as first-class
              citizens. Then a remittance that a family in London can actually
              use, so the core is never allowed to become an abstraction.
            </p>
            <p>
              Cush Payments is how the diaspora feels it. Cush Core is how
              banks, PSPs, fintechs, and governments own it. Two products.
              One house.
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 md:px-8">
        <p className="text-xs tracking-[0.18em] text-champagne uppercase">
          Origination
        </p>
        <h2 className="mt-3 max-w-2xl font-display text-4xl text-ink">
          From all over the world. Terminating in Africa.
        </h2>
        <p className="mt-4 max-w-xl text-base text-stone">
          The diaspora starts the transfer wherever they live. Cush settles
          it on African rails — Accra first, then the rest of the continent.
        </p>
        <OriginationMap className="mt-10" />
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 md:px-8">
        <p className="text-xs tracking-[0.18em] text-champagne uppercase">
          Leadership
        </p>
        <h2 className="mt-3 font-display text-4xl text-ink">
          People who have already sat in the rooms that matter.
        </h2>
        <div className="mt-10 grid gap-4 md:grid-cols-2">
          {leadership.map((person) => (
            <article
              key={person.name}
              className="rounded-xl bg-surface p-6 shadow-[0_0_0_1px_rgb(23_20_17_/_0.08)] md:p-8"
            >
              <div className="flex items-center gap-4">
                <div className="flex size-14 items-center justify-center rounded-full bg-paper font-display text-lg text-champagne shadow-[0_0_0_1px_rgb(23_20_17_/_0.08)]">
                  {person.initials}
                </div>
                <div>
                  <h3 className="text-lg text-ink">{person.name}</h3>
                  <p className="text-sm text-stone">
                    {person.role} · {person.years}
                  </p>
                </div>
              </div>
              <p className="mt-4 text-sm text-stone">{person.bio}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {person.tags.map((t) => (
                  <span
                    key={t}
                    className="rounded-full px-2.5 py-1 text-[11px] text-stone shadow-[0_0_0_1px_rgb(23_20_17_/_0.1)]"
                  >
                    {t}
                  </span>
                ))}
              </div>
              <a
                href={person.linkedin}
                target="_blank"
                rel="noreferrer"
                className="mt-4 inline-flex items-center gap-1 text-sm text-champagne"
              >
                LinkedIn <ArrowUpRight className="size-3.5" />
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className="border-t border-line">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-20 md:grid-cols-2 md:px-8">
          <div>
            <h2 className="font-display text-4xl text-ink">Write to us.</h2>
            <p className="mt-3 text-stone">
              Founders, licensing, and business — one inbox. The waitlist is
              the fastest door.
            </p>
            <Button className="mt-6" onClick={() => openWaitlist("sender")}>
              Join the waitlist
            </Button>
          </div>
          <a
            className="self-center text-base break-all text-ink md:justify-self-end md:text-lg"
            href={`mailto:${brand.email}`}
          >
            {brand.email}
          </a>
        </div>
      </section>
    </main>
  );
}
