import { createFileRoute, Link } from "@tanstack/react-router";
import { ArchitectureExplorer } from "@/components/architecture-explorer";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { coreModules, rails } from "@/lib/site-data";
import { useWaitlist } from "@/lib/waitlist-store";

export const Route = createFileRoute("/core")({
  component: CorePage,
  head: () => ({
    meta: [
      { title: "Cush Core — AI-native core banking for Africa" },
      {
        name: "description",
        content:
          "License Cush Core: immutable BLAKE3 ledger, agentic orchestration, PAPSS-native rails. For banks, PSPs, fintechs, and governments.",
      },
    ],
  }),
});

function CorePage() {
  const openWaitlist = useWaitlist((s) => s.openWith);

  return (
    <main>
      <section className="relative min-h-[80svh] overflow-hidden pt-[4.5rem]">
        <img
          src="/images/core-hall.jpg"
          alt="Architectural hall of stone and brass"
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/45 to-ink/25" />
        <div className="relative mx-auto flex min-h-[80svh] max-w-6xl flex-col justify-end px-5 py-16 md:px-8">
          <Badge>Cush Core</Badge>
          <h1 className="mt-4 max-w-4xl font-display text-[clamp(2.15rem,3.4vw+1.05rem,4.5rem)] text-bone">
            The operating system African money was missing.
          </h1>
          <p className="mt-5 max-w-xl text-base text-bone-2">
            A production-grade, AI-native core banking and payments platform.
            Licensed to banks, PSPs, fintechs, and governments. The same stack
            that powers Cush Payments.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button size="lg" onClick={() => openWaitlist("institution")}>
              Talk to licensing
            </Button>
            <Button size="lg" variant="onPhoto" asChild>
              <Link to="/payments">See it running as Payments</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="border-b border-line">
        <div className="mx-auto grid max-w-6xl gap-8 px-5 py-14 md:grid-cols-3 md:px-8">
          {[
            {
              k: "Ready for production",
              v: "Cush Payments is the first product on this core — opening with the private beta.",
            },
            {
              k: "~$1 / customer / month",
              v: "Engineered for African unit economics, not European core licensing maths.",
            },
            {
              k: "Multi-entity by design",
              v: "UK Ltd, Ghana Ltd, US subsidiary — the legal map a real payments group needs.",
            },
          ].map((s) => (
            <div key={s.k}>
              <p className="font-display text-2xl text-ink">{s.k}</p>
              <p className="mt-2 text-sm text-stone">{s.v}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 md:px-8">
        <p className="text-xs tracking-[0.18em] text-champagne uppercase">
          Stack
        </p>
        <h2 className="mt-3 max-w-2xl font-display text-4xl text-ink">
          Four layers. Nothing bolted on.
        </h2>
        <p className="mt-4 max-w-2xl text-stone">
          Most African institutions are stitching a European core to a
          payments hub to a wallet vendor. Cush Core is one system of record
          from posting to PAPSS.
        </p>
        <div className="mt-12">
          <ArchitectureExplorer />
        </div>
      </section>

      <section className="bg-surface">
        <div className="mx-auto max-w-6xl px-5 py-24 md:px-8">
          <p className="text-xs tracking-[0.18em] text-champagne uppercase">
            Catalogue
          </p>
          <h2 className="mt-3 font-display text-4xl text-ink">
            What you can run on it.
          </h2>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {coreModules.map((m) => (
              <article
                key={m.title}
                className="rounded-xl bg-paper p-6 shadow-[0_0_0_1px_rgb(23_20_17_/_0.08)]"
              >
                <h3 className="text-lg text-ink">{m.title}</h3>
                <p className="mt-2 text-sm text-stone">{m.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 md:px-8">
        <p className="text-xs tracking-[0.18em] text-champagne uppercase">
          Connectivity
        </p>
        <h2 className="mt-3 max-w-2xl font-display text-4xl text-ink">
          Western rails on the way in. African rails on the way out.
        </h2>
        <ul className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-4">
          {rails.map((r) => (
            <li
              key={r.name}
              className="rounded-lg bg-surface px-4 py-4 shadow-[0_0_0_1px_rgb(23_20_17_/_0.08)]"
            >
              <p className="text-sm text-ink">{r.name}</p>
              <p className="text-xs text-ash">{r.region}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="relative overflow-hidden">
        <img
          src="/images/still-coins.jpg"
          alt="Pound and cedi on a dark desk"
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-ink/75" />
        <div className="relative mx-auto max-w-6xl px-5 py-24 md:px-8">
          <p className="text-xs tracking-[0.18em] text-champagne uppercase">
            Compliance
          </p>
          <h2 className="mt-3 max-w-2xl font-display text-4xl text-bone">
            Built to be examined.
          </h2>
          <p className="mt-4 max-w-xl text-bone-2">
            KYC, AML, transaction monitoring, PSD2 and DORA-aligned controls.
            Architecture ready for Bank of Ghana sandbox engagement and
            multi-jurisdiction licensing. Every posting sealed. Every decision
            reconstructable.
          </p>
          <ul className="mt-8 grid gap-3 sm:grid-cols-2 md:max-w-xl">
            {[
              "Immutable BLAKE3 ledger",
              "Policy-bound AI agents",
              "Multi-entity books",
              "Sandbox-ready design",
            ].map((x) => (
              <li key={x} className="text-sm text-bone">
                <span className="mr-3 inline-block h-px w-5 bg-champagne align-middle" />
                {x}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="border-t border-line bg-surface">
        <div className="mx-auto flex max-w-6xl flex-col items-start gap-6 px-5 py-16 md:flex-row md:items-end md:justify-between md:px-8">
          <div>
            <h2 className="font-display text-4xl text-ink">
              Bring your institution onto the rails.
            </h2>
            <p className="mt-2 max-w-md text-sm text-stone">
              Tell us what you want to offer. We’ll walk the stack with you.
            </p>
          </div>
          <Button size="lg" onClick={() => openWaitlist("institution")}>
            Talk to licensing
          </Button>
        </div>
      </section>
    </main>
  );
}
