import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { ArchitectureExplorer } from "@/components/architecture-explorer";
import { CorridorTheater } from "@/components/corridor-theater";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { brand, leadership, markets, quotes } from "@/lib/site-data";
import { cn } from "@/lib/utils";
import { useWaitlist } from "@/lib/waitlist-store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [audience, setAudience] = useState<"payments" | "core">("payments");
  const openWaitlist = useWaitlist((s) => s.openWith);
  const payments = audience === "payments";

  return (
    <main>
      <section className="relative min-h-[78svh] overflow-hidden">
        <img
          src="/images/hero-corridor.jpg"
          alt="A corridor of light connecting a London evening to Accra at golden hour"
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ink/25 via-ink/45 to-ink/80" />
        <div className="relative mx-auto flex min-h-[78svh] max-w-6xl flex-col justify-end px-5 pt-28 pb-16 md:px-8 md:pb-20">
          <p className="reveal text-xs tracking-[0.22em] text-champagne uppercase">
            Cush Payments · Cush Core
          </p>
          <h1 className="reveal reveal-2 mt-4 max-w-4xl font-display text-[clamp(2.15rem,3.4vw+1.05rem,4.5rem)] text-bone">
            Africa's payment{" "}
            <span className="block sm:inline">platform.</span>
          </h1>
          <p className="reveal reveal-3 mt-5 max-w-xl text-base text-bone-2 md:text-lg">
            {brand.promise}
          </p>

          <div className="reveal reveal-4 mt-8 flex w-fit rounded-full bg-ink/40 p-1 shadow-[0_0_0_1px_rgb(255_252_248_/_0.18)]">
            <button
              type="button"
              onClick={() => setAudience("payments")}
              className={cn(
                "h-9 rounded-full px-3 text-xs transition-colors sm:h-10 sm:px-4 sm:text-sm",
                payments ? "bg-champagne text-bone" : "text-bone hover:text-bone",
              )}
            >
              Sending home
            </button>
            <button
              type="button"
              onClick={() => setAudience("core")}
              className={cn(
                "h-9 rounded-full px-3 text-xs transition-colors sm:h-10 sm:px-4 sm:text-sm",
                !payments ? "bg-champagne text-bone" : "text-bone hover:text-bone",
              )}
            >
              Licensing rails
            </button>
          </div>

          <div className="reveal reveal-5 mt-6 max-w-lg">
            {payments ? (
              <p className="text-sm text-bone-2">
                Send to mobile wallets and bank accounts across Africa.
                Transparent 1.8%. Mid-market FX. They see it before you pocket
                the phone.
              </p>
            ) : (
              <p className="text-sm text-bone-2">
                License the production core behind Cush Payments — immutable
                ledger, agentic routing, PAPSS-native settlement — under your
                own brand.
              </p>
            )}
            <div className="mt-5 flex flex-col gap-3 sm:flex-row">
              <Button
                size="lg"
                onClick={() =>
                  openWaitlist(payments ? "sender" : "institution")
                }
              >
                {payments ? "Join the waitlist" : "Talk to licensing"}
                <ArrowUpRight className="size-4" />
              </Button>
              <Button size="lg" variant="onPhoto" asChild>
                <Link to={payments ? "/payments" : "/core"}>
                  {payments ? "How sending works" : "Explore Cush Core"}
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-8 md:px-8">
        <CorridorTheater />
      </section>

      <section className="mx-auto grid max-w-6xl gap-4 px-5 py-16 md:grid-cols-2 md:px-8">
        <Link
          to="/payments"
          className="group relative min-h-[28rem] overflow-hidden rounded-xl"
        >
          <img
            src="/images/receive-hands.jpg"
            alt="Hands holding a phone in a sunlit Accra apartment"
            className="absolute inset-0 size-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/30 to-ink/10" />
          <div className="relative flex h-full flex-col justify-end p-6 md:p-8">
            <Badge>Cush Payments</Badge>
            <h2 className="mt-3 font-display text-4xl text-bone">
              For the diaspora.
            </h2>
            <p className="mt-2 max-w-sm text-sm text-bone-2">
              A premium remittance. No hidden FX. Wallets and banks in Ghana
              first, then the rest of the map.
            </p>
            <span className="mt-4 inline-flex items-center gap-1 text-sm text-champagne">
              Open Payments <ArrowUpRight className="size-4" />
            </span>
          </div>
        </Link>
        <Link
          to="/core"
          className="group relative min-h-[28rem] overflow-hidden rounded-xl"
        >
          <img
            src="/images/core-hall.jpg"
            alt="A dark architectural hall of stone and brass, like a ledger"
            className="absolute inset-0 size-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-ink/10" />
          <div className="relative flex h-full flex-col justify-end p-6 md:p-8">
            <Badge>Cush Core</Badge>
            <h2 className="mt-3 font-display text-4xl text-bone">
              For the institutions.
            </h2>
            <p className="mt-2 max-w-sm text-sm text-bone-2">
              The same rails, licensed. Accounts, cards, loans, payouts —
              proven by the product we run ourselves.
            </p>
            <span className="mt-4 inline-flex items-center gap-1 text-sm text-champagne">
              Open Core <ArrowUpRight className="size-4" />
            </span>
          </div>
        </Link>
      </section>

      <section className="border-y border-line">
        <div className="mx-auto grid max-w-6xl grid-cols-2 divide-x divide-line md:grid-cols-4">
          {[
            ["$104B+", "African remittance inflows"],
            ["1.8%", "Transparent standard fee"],
            ["Seconds", "Target settlement"],
            ["~$1", "Core opex / customer / month"],
          ].map(([stat, label]) => (
            <div key={label} className="px-5 py-8 md:px-8">
              <p className="font-display text-3xl text-ink md:text-4xl">
                {stat}
              </p>
              <p className="mt-2 text-sm text-stone">{label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 md:px-8">
        <p className="text-xs tracking-[0.18em] text-champagne uppercase">
          Why two products
        </p>
        <h2 className="mt-3 max-w-3xl font-display text-4xl text-ink md:text-5xl">
          We didn’t bolt a remittance app onto someone else’s core. We built
          the core, then sent the first transfer.
        </h2>
        <p className="mt-5 max-w-2xl text-base text-stone">
          Africa has paid correspondent-bank rent for a generation. Cush Core
          treats PAPSS, GHIPSS, and mobile money as first-class rails. Cush
          Payments is the living proof — the product we eat, the product your
          customers will feel.
        </p>
        <div className="mt-12">
          <ArchitectureExplorer />
        </div>
      </section>

      <section className="relative overflow-hidden">
        <img
          src="/images/accra-coast.jpg"
          alt="Accra coastline at dusk"
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-ink/70" />
        <div className="relative mx-auto max-w-6xl px-5 py-24 md:px-8">
          <p className="text-xs tracking-[0.18em] text-champagne uppercase">
            Coverage
          </p>
          <h2 className="mt-3 font-display text-4xl text-bone">
            One house. Many corridors.
          </h2>
          <ul className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {markets.map((m) => (
              <li
                key={m.name}
                className="rounded-lg bg-ink/60 px-4 py-4 shadow-[0_0_0_1px_rgb(255_252_248_/_0.12)]"
              >
                <p className="text-sm text-bone">{m.name}</p>
                <p className="text-xs text-stone">{m.city}</p>
                <p className="mt-3 text-[11px] tracking-wide text-champagne uppercase">
                  {m.status}
                </p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 md:px-8">
        <p className="text-xs tracking-[0.18em] text-champagne uppercase">
          From the corridor
        </p>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {quotes.map((q) => (
            <blockquote
              key={q.meta}
              className="rounded-xl bg-surface p-6 shadow-[0_0_0_1px_rgb(23_20_17_/_0.08)]"
            >
              <p className="font-display text-2xl text-ink italic">
                “{q.quote}”
              </p>
              <footer className="mt-4 text-xs tracking-wide text-ash uppercase">
                {q.meta}
              </footer>
            </blockquote>
          ))}
        </div>
      </section>

      <section className="border-t border-line">
        <div className="mx-auto max-w-6xl px-5 py-24 md:px-8">
          <p className="text-xs tracking-[0.18em] text-champagne uppercase">
            Leadership
          </p>
          <h2 className="mt-3 font-display text-4xl text-ink">
            Built by people who have already run the rails.
          </h2>
          <div className="mt-10 grid gap-4 md:grid-cols-2">
            {leadership.map((person) => (
              <article
                key={person.name}
                className="rounded-xl bg-surface p-6 shadow-[0_0_0_1px_rgb(23_20_17_/_0.08)] md:p-8"
              >
                <div className="flex items-center gap-4">
                  <div className="flex size-14 items-center justify-center rounded-full bg-paper font-display text-lg text-champagne shadow-[0_0_0_1px_rgb(23_20_17_/_0.08)]">
                    {person.initials}
                  </div>
                  <div>
                    <h3 className="text-lg text-ink">{person.name}</h3>
                    <p className="text-sm text-bone-2">
                      {person.role} · {person.years}
                    </p>
                  </div>
                </div>
                <p className="mt-4 text-sm text-stone">{person.bio}</p>
                <a
                  href={person.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-4 inline-flex items-center gap-1 text-sm text-champagne hover:text-ink"
                >
                  LinkedIn <ArrowUpRight className="size-3.5" />
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-line bg-surface">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-8 px-5 py-20 md:flex-row md:items-end md:px-8">
          <div>
            <h2 className="font-display text-4xl text-ink md:text-5xl">
              The waitlist is the front door.
            </h2>
            <p className="mt-3 max-w-lg text-stone">
              Private beta. UK → Ghana opens first. Sandbox conversations for
              institutions. Tell us which you are.
            </p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button size="lg" onClick={() => openWaitlist("sender")}>
              I’m sending
            </Button>
            <Button
              size="lg"
              variant="secondary"
              onClick={() => openWaitlist("institution")}
            >
              I’m licensing
            </Button>
          </div>
        </div>
      </section>
    </main>
  );
}
