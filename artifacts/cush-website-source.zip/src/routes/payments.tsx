import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, Shield, Wallet, Zap } from "lucide-react";
import { CorridorTheater } from "@/components/corridor-theater";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { markets } from "@/lib/site-data";
import { useWaitlist } from "@/lib/waitlist-store";

export const Route = createFileRoute("/payments")({
  component: PaymentsPage,
  head: () => ({
    meta: [
      { title: "Cush Payments — Send money to Africa" },
      {
        name: "description",
        content:
          "Premium remittances to African mobile wallets and bank accounts. 1.8% transparent fee, mid-market FX, seconds not days.",
      },
    ],
  }),
});

const steps = [
  {
    n: "01",
    title: "Verify once",
    body: "Open an account. Complete KYC in minutes. We designed the checks for regulation, not friction theatre.",
  },
  {
    n: "02",
    title: "Name the person",
    body: "Mobile wallet or bank account. MTN MoMo, bank rails, local settlement. You see the receive amount before you commit.",
  },
  {
    n: "03",
    title: "Send. Watch the seal.",
    body: "Funds leave on Faster Payments, land on PAPSS, arrive as cedis in a wallet. Tracked in real time, sealed on Cush Core.",
  },
];

function PaymentsPage() {
  const openWaitlist = useWaitlist((s) => s.openWith);

  return (
    <main>
      <section className="relative min-h-[70svh] overflow-hidden pt-[4.5rem]">
        <img
          src="/images/sender-london.jpg"
          alt="A man in London sending from his phone at dusk"
          className="absolute inset-0 size-full object-cover object-[center_20%]"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/80 via-ink/55 to-ink/20" />
        <div className="relative mx-auto flex min-h-[70svh] max-w-6xl flex-col justify-end px-5 py-16 md:px-8">
          <Badge>Cush Payments</Badge>
          <h1 className="mt-4 max-w-3xl font-display text-[clamp(2.15rem,3.4vw+1.05rem,4.5rem)] text-bone">
            They have it before you put the phone down.
          </h1>
          <p className="mt-5 max-w-lg text-base text-bone-2">
            A remittance built like a private bank product: 1.8%, mid-market
            FX, mobile wallets and bank accounts. UK → Ghana opens first.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button size="lg" onClick={() => openWaitlist("sender")}>
              Join the waitlist
            </Button>
            <Button size="lg" variant="onPhoto" asChild>
              <Link to="/core">Powered by Cush Core</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-4 px-5 py-16 md:grid-cols-3 md:px-8">
        {[
          {
            icon: Zap,
            title: "Seconds, by design",
            body: "Faster Payments in. PAPSS and GHIPSS out. The wait of correspondent banking is the thing we refused to inherit.",
          },
          {
            icon: Wallet,
            title: "Wallets and banks",
            body: "Send to MTN MoMo, bank accounts, and local rails. The last mile is African infrastructure, not a cash-pickup queue.",
          },
          {
            icon: Shield,
            title: "Shown before sent",
            body: "Fee, rate, and receive amount on one screen. No FX surprise on the other side of the call with family.",
          },
        ].map((item) => (
          <article
            key={item.title}
            className="rounded-xl bg-surface p-6 shadow-[0_0_0_1px_rgb(23_20_17_/_0.08)]"
          >
            <item.icon className="size-5 text-champagne" />
            <h2 className="mt-4 text-lg text-ink">{item.title}</h2>
            <p className="mt-2 text-sm text-stone">{item.body}</p>
          </article>
        ))}
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-8 md:px-8">
        <CorridorTheater />
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 md:px-8">
        <p className="text-xs tracking-[0.18em] text-champagne uppercase">
          How it works
        </p>
        <h2 className="mt-3 font-display text-4xl text-ink">
          Three moves. No mystery.
        </h2>
        <ol className="mt-10 grid gap-6 md:grid-cols-3">
          {steps.map((s) => (
            <li key={s.n}>
              <p className="font-mono text-xs text-champagne">{s.n}</p>
              <h3 className="mt-2 font-display text-2xl text-ink">{s.title}</h3>
              <p className="mt-2 text-sm text-stone">{s.body}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="grid md:grid-cols-2">
        <div className="relative min-h-[22rem]">
          <img
            src="/images/receive-hands.jpg"
            alt="Receiving a transfer in Accra"
            className="absolute inset-0 size-full object-cover"
          />
        </div>
        <div className="flex flex-col justify-center bg-surface px-5 py-16 md:px-12">
          <p className="text-xs tracking-[0.18em] text-champagne uppercase">
            Transparency
          </p>
          <h2 className="mt-3 font-display text-4xl text-ink">
            1.8%. That’s the product.
          </h2>
          <p className="mt-4 max-w-md text-stone">
            Most remittance brands hide the real cost in the rate. We take a
            stated fee on mid-market FX and show the receive amount before
            you confirm. If we can’t say it on the screen, we don’t charge
            it.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 md:px-8">
        <div className="flex items-end justify-between gap-6">
          <div>
            <p className="text-xs tracking-[0.18em] text-champagne uppercase">
              Corridors
            </p>
            <h2 className="mt-3 font-display text-4xl text-ink">
              Ghana first. Then the map.
            </h2>
          </div>
          <Link
            to="/business"
            className="hidden items-center gap-1 text-sm text-champagne sm:inline-flex"
          >
            Paying teams instead? <ArrowUpRight className="size-4" />
          </Link>
        </div>
        <ul className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {markets.map((m) => (
            <li
              key={m.name}
              className="rounded-lg bg-surface px-4 py-4 shadow-[0_0_0_1px_rgb(23_20_17_/_0.08)]"
            >
              <p className="text-sm text-ink">{m.name}</p>
              <p className="text-xs text-stone">{m.city}</p>
              <p className="mt-3 text-[11px] tracking-wide text-champagne uppercase">
                {m.status}
              </p>
            </li>
          ))}
        </ul>
      </section>

      <section className="border-t border-line bg-surface">
        <div className="mx-auto flex max-w-6xl flex-col items-start gap-6 px-5 py-16 md:flex-row md:items-end md:justify-between md:px-8">
          <h2 className="font-display text-4xl text-ink">
            Be on the first corridor.
          </h2>
          <Button size="lg" onClick={() => openWaitlist("sender")}>
            Request access
          </Button>
        </div>
      </section>
    </main>
  );
}
